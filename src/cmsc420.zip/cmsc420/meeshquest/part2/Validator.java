package cmsc420.meeshquest.part2;

public interface Validator {

	public boolean isValid();
}
