package cmsc420.part2;

public interface Validator {

	public boolean isValid();
}
