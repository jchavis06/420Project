package cmsc420.meeshquest.part2;
import cmsc420.xml.XmlUtility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public interface XmlOutput {

	public Element printOutput();
}
