package cmsc420.exception;

public class AirportOutOfBoundsThrowable extends Throwable{
	public AirportOutOfBoundsThrowable() {
	}

	public AirportOutOfBoundsThrowable(String message) {
		super(message);
	}
}
