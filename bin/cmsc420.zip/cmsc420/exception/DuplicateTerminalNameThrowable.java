package cmsc420.exception;

public class DuplicateTerminalNameThrowable extends Throwable {

	public DuplicateTerminalNameThrowable () {}
	
	public DuplicateTerminalNameThrowable(String message) {
		super(message);
	}
}
