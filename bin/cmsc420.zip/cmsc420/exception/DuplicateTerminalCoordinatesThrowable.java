package cmsc420.exception;

public class DuplicateTerminalCoordinatesThrowable extends Throwable {

	public DuplicateTerminalCoordinatesThrowable() {}
	
	public DuplicateTerminalCoordinatesThrowable(String message) {
		super(message);
	}
}
