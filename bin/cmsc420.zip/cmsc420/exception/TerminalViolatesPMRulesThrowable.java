package cmsc420.exception;

public class TerminalViolatesPMRulesThrowable extends Throwable {

	public TerminalViolatesPMRulesThrowable(){}
	
	public TerminalViolatesPMRulesThrowable(String message) {
		super(message);
	}
	
}
