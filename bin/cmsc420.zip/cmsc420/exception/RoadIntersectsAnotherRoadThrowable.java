package cmsc420.exception;

public class RoadIntersectsAnotherRoadThrowable extends Throwable {

	public RoadIntersectsAnotherRoadThrowable(){}
	
	public RoadIntersectsAnotherRoadThrowable(String message) {
		super(message);
	}
}
