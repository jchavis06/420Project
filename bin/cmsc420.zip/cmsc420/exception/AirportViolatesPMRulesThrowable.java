package cmsc420.exception;

public class AirportViolatesPMRulesThrowable extends Throwable {

	public AirportViolatesPMRulesThrowable() {
		
	}
	
	public AirportViolatesPMRulesThrowable(String message) {
		super(message);
	}
}
