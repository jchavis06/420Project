package cmsc420.exception;

public class ConnectingCityNotInSameMetropoleThrowable extends Throwable{

	public ConnectingCityNotInSameMetropoleThrowable() {
		
	}
	
	public ConnectingCityNotInSameMetropoleThrowable(String message) {
		super(message);
	}
}
