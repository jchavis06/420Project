package cmsc420.exception;

public class AirportNotInSameMetropoleThrowable extends Throwable {

	public AirportNotInSameMetropoleThrowable(){}
	
	public AirportNotInSameMetropoleThrowable(String message) {
		super(message);
	}
}
