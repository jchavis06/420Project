package cmsc420.exception;

public class ConnectingCityNotMappedThrowable extends Throwable{

	public ConnectingCityNotMappedThrowable(){}
	
	public ConnectingCityNotMappedThrowable(String message) {
		super(message);
	}
}
