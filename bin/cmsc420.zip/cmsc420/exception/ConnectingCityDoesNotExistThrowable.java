package cmsc420.exception;

public class ConnectingCityDoesNotExistThrowable extends Throwable{

	public ConnectingCityDoesNotExistThrowable() {
	}

	public ConnectingCityDoesNotExistThrowable(String message) {
		super(message);
	}
}
