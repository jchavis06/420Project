package cmsc420.exception;

public class TerminalOutOfBoundsThrowable extends Throwable{
	public TerminalOutOfBoundsThrowable() {
	}

	public TerminalOutOfBoundsThrowable(String message) {
		super(message);
	}
}
