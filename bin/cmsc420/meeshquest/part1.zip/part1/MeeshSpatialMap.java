package cmsc420.meeshquest.part1;

public class MeeshSpatialMap {

	public MeeshSpatialMap() {
		
	}
}
